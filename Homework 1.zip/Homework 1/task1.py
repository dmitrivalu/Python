num_1 = 1
num_2 = 2
print(num_1 + num_2)

Text_user = input("Введите Ваше имя: ")
Age_user = input("Введите Ваш возраст ")
print("Привет " + Text_user + "." + "Ваш возраст :" + Age_user)
