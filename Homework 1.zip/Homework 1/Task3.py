Us_num = input("Введите целое положительное число: ")
Us_num1 = Us_num * 2
Us_num2 = Us_num * 3
print(int(Us_num) + int(Us_num1) + int(Us_num2))
