num = int(input("Введите целое положительное число: "))
x_max = 0
while num > 10:
    x = num % 10
    if x_max < x:
        x_max = x
    num = num // 10

print("Самое большое число:" + str(x_max))
